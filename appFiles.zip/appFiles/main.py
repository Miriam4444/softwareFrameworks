from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database import engine, SessionLocal
from .models import User, Molecule
from .database import Base
from .schemas import MoleculeCreate, UserCreate

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)

Base.metadata.create_all(bind=engine)

@app.get("/")
def root():
    return {"message": "API is running!"}

@app.get("/users-with-molecules")
def get_users_with_molecules():
    db = SessionLocal()
    users = db.query(User).all()
    result = []
    for user in users:
        result.append({
            "idUser": user.idUser,
            "username": user.username,
            "molecules": [
                {"name": m.name, "formula": m.formula}
                for m in user.molecules
            ]
        })
    return result

@app.post("/molecules")
def create_molecule(molecule: MoleculeCreate):
    db = SessionLocal()
    new_molecule = Molecule(
        name=molecule.name,
        formula=molecule.formula,
        description=molecule.description,
        ownerId=molecule.ownerId
    )
    db.add(new_molecule)
    db.commit()
    db.refresh(new_molecule)
    return {"message": "Molecule created!", "molecule": new_molecule.name}

@app.post("/users")
def create_user(user: UserCreate):
    db = SessionLocal()
    new_user = User(
        username=user.username,
        password=user.password
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return {"message": "User created!", "username": new_user.username}

@app.delete("/users/{user_id}")
def delete_user(user_id: int):
    db = SessionLocal()
    user = db.query(User).filter(User.idUser == user_id).first()
    if not user:
        return {"message": "User not found"}
    db.delete(user)
    db.commit()
    return {"message": f"{user.username} deleted!"}