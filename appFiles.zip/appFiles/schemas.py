from pydantic import BaseModel

class MoleculeCreate(BaseModel):
    name: str
    formula: str
    description: str = ""
    ownerId: int

class UserCreate(BaseModel):
    username: str
    password: str