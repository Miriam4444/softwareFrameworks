from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship
from .database import Base

class User(Base):
    __tablename__ = "User"

    idUser = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True)
    password = Column(String(255))

    molecules = relationship("Molecule", back_populates="owner")

class Molecule(Base):
    __tablename__ = "Molecule"

    idMolecule = Column(Integer, primary_key=True, index=True)
    name = Column(String(45))
    formula = Column(String(80))
    description = Column(String(500))
    ownerId = Column(Integer, ForeignKey("User.idUser"), nullable=True)

    owner = relationship("User", back_populates="molecules")