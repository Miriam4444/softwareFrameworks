# this was old main thing to test is fastAPI is working

'''
from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def read_root():
    return {"FastAPI is working!"}

'''
