-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`User`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`User` (
  `idUser` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(45) NOT NULL,
  `password` VARCHAR(300) NOT NULL,
  PRIMARY KEY (`idUser`),
  UNIQUE INDEX `username_UNIQUE` (`username` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Class`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Class` (
  `idClass` INT NOT NULL AUTO_INCREMENT,
  `className` VARCHAR(200) NOT NULL,
  `idTeacher` INT NOT NULL,
  INDEX `fkTeacher_idx` (`idTeacher` ASC) VISIBLE,
  PRIMARY KEY (`idClass`),
  CONSTRAINT `fkTeacher`
    FOREIGN KEY (`idTeacher`)
    REFERENCES `mydb`.`User` (`idUser`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`ClassMember`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`ClassMember` (
  `idUser` INT NOT NULL,
  `idClass` INT NOT NULL,
  PRIMARY KEY (`idUser`, `idClass`),
  INDEX `fkClassId_idx` (`idClass` ASC) VISIBLE,
  CONSTRAINT `fkUserId`
    FOREIGN KEY (`idUser`)
    REFERENCES `mydb`.`User` (`idUser`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fkClassId`
    FOREIGN KEY (`idClass`)
    REFERENCES `mydb`.`Class` (`idClass`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Folder`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Folder` (
  `idFolder` INT NOT NULL AUTO_INCREMENT,
  `folderName` VARCHAR(100) NOT NULL,
  `userId` INT NOT NULL,
  `parentFolderId` INT NULL,
  PRIMARY KEY (`idFolder`),
  INDEX `fkUserId_idx` (`userId` ASC) VISIBLE,
  INDEX `fkFolderId_idx` (`parentFolderId` ASC) VISIBLE,
  CONSTRAINT `fkFolderUserId`
    FOREIGN KEY (`userId`)
    REFERENCES `mydb`.`User` (`idUser`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fkFolderId2`
    FOREIGN KEY (`parentFolderId`)
    REFERENCES `mydb`.`Folder` (`idFolder`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Molecule`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Molecule` (
  `idMolecule` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `formula` VARCHAR(80) NOT NULL,
  `description` VARCHAR(500) NULL,
  `folderId` INT NULL,
  PRIMARY KEY (`idMolecule`),
  INDEX `fkFolderId_idx` (`folderId` ASC) VISIBLE,
  CONSTRAINT `fkMolFolderId`
    FOREIGN KEY (`folderId`)
    REFERENCES `mydb`.`Folder` (`idFolder`)
    ON DELETE SET NULL
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Atom`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Atom` (
  `idAtom` INT NOT NULL AUTO_INCREMENT,
  `element` VARCHAR(3) NOT NULL,
  `xCoord` FLOAT NOT NULL,
  `yCoord` FLOAT NOT NULL,
  `zCoord` FLOAT NOT NULL,
  `idMolecule` INT NOT NULL,
  PRIMARY KEY (`idAtom`),
  INDEX `fkIdMolecule_idx` (`idMolecule` ASC) VISIBLE,
  CONSTRAINT `fkIdMolecule`
    FOREIGN KEY (`idMolecule`)
    REFERENCES `mydb`.`Molecule` (`idMolecule`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Bond`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Bond` (
  `idBond` INT NOT NULL AUTO_INCREMENT,
  `bondType` ENUM('s', 'd', 't') NOT NULL COMMENT 's := single bond\nd := double bond\nt := triple bond',
  `idAtom1` INT NOT NULL,
  `idAtom2` INT NOT NULL,
  PRIMARY KEY (`idBond`),
  INDEX `fkAtom1_idx` (`idAtom1` ASC) VISIBLE,
  INDEX `fkAtom2_idx` (`idAtom2` ASC) VISIBLE,
  CONSTRAINT `fkAtom1`
    FOREIGN KEY (`idAtom1`)
    REFERENCES `mydb`.`Atom` (`idAtom`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fkAtom2`
    FOREIGN KEY (`idAtom2`)
    REFERENCES `mydb`.`Atom` (`idAtom`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
